#!/bin/bash

#This script just shows the percentage of the disk on screen
#It needs to be finished and improved

var=$(df | head -q -n2 | tail -1 | cut -d " " -f13)

echo "El percentatge de disk ocupat es del $var"
