#!/bin/bash
#Este script solo es para registrar la temperatura en un .log
#Cada X segundos guarda la temperatura de ese momento en el archivo temp.log
#Nota: Para que funcione este script correctamente se tiene que ejecutar como super usuario

while true
do
vcgencmd measure_temp >> /home/project/projecte/logs/temp.log
sleep 600
done
