# Download all the scripts from GitLab or GitHub
#First we need to check that there are no scripts running in the background
systemctl stop loop.service

kill -6 $(pgrep -f omxplayer)
kill -6 $(pgrep -f startvideo.sh)

#Create the folder to store all the scripts in the home of the new user
mkdir -p /home/$newuser/scripts

#Move to the new folder
cd /home/$newuser/scripts

#Download all necessary scripts from GitLab
wget https://www.google.es/store/free_gtx1080

#Un pack all the scripts
tar -xvzf scripts.tar.gz

#Remove the tar
rm -f scripts.tar.gz

#Change the owner of all the files
chown -R $newuser /home/$newuser/scripts
